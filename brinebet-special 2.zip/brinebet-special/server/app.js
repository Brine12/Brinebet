// Full-featured demo server: auth (JWT), wallet, bets, lottery with payouts credited to user balances.
const express = require('express');
const path = require('path');
const crypto = require('crypto');
const sqlite3 = require('sqlite3').verbose();
const db = require('./db');
const bodyParser = require('body-parser');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 4000;
const ADMIN_SECRET = process.env.ADMIN_SECRET || 'demo-admin-secret';
const JWT_SECRET = process.env.JWT_SECRET || 'demo-jwt-secret';

app.use(bodyParser.json());
// Security middlewares
app.use(helmet());
app.use(cors({ origin: true }));
// Basic rate limiter: 100 requests per 15 minutes per IP
const limiter = rateLimit({ windowMs: 15*60*1000, max: 100 });
app.use(limiter);
app.use(express.static(path.join(__dirname, '..', 'public')));

// Helpers
function runAsync(sql, params=[]){
  return new Promise((resolve,reject)=>{
    db.run(sql, params, function(err){
      if(err) reject(err); else resolve(this);
    });
  });
}
function allAsync(sql, params=[]){
  return new Promise((resolve,reject)=>{
    db.all(sql, params, (err,rows)=> err?reject(err):resolve(rows));
  });
}
function getAsync(sql, params=[]){
  return new Promise((resolve,reject)=>{
    db.get(sql, params, (err,row)=> err?reject(err):resolve(row));
  });
}

// --- Auth endpoints
app.post('/api/register', async (req,res)=>{
  const { email, password } = req.body;
  if(!email || !password) return res.status(400).json({ error:'missing fields' });
  try{
    const hash = await bcrypt.hash(password, 10);
    const info = await runAsync('INSERT INTO users (email, password_hash) VALUES (?, ?)', [email, hash]);
    const id = info.lastID;
    const token = jwt.sign({ id, email }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token });
  }catch(e){
    if(e && e.code === 'SQLITE_CONSTRAINT') return res.status(400).json({ error:'email exists' });
    console.error(e); res.status(500).json({ error:'db' });
  }
});

app.post('/api/login', async (req,res)=>{
  const { email, password } = req.body;
  if(!email || !password) return res.status(400).json({ error:'missing fields' });
  try{
    const user = await getAsync('SELECT id,email,password_hash,balance FROM users WHERE email = ?', [email]);
    if(!user) return res.status(400).json({ error:'invalid credentials' });
    const ok = await bcrypt.compare(password, user.password_hash);
    if(!ok) return res.status(400).json({ error:'invalid credentials' });
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, balance: user.balance });
  }catch(e){ console.error(e); res.status(500).json({ error:'db' }); }
});

// auth middleware
function auth(req,res,next){
  const a = req.headers.authorization;
  if(!a) return res.status(401).json({ error:'missing auth' });
  const token = a.split(' ')[1];
  try{
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  }catch(e){ return res.status(401).json({ error:'invalid token' }); }
}

// wallet deposit (demo)
app.post('/api/deposit', auth, async (req,res)=>{
  const { amount } = req.body;
  const amt = Number(amount) || 0;
  if(amt <= 0) return res.status(400).json({ error:'invalid amount' });
  await runAsync('UPDATE users SET balance = balance + ? WHERE id = ?', [amt, req.user.id]);
  const user = await getAsync('SELECT id,email,balance FROM users WHERE id = ?', [req.user.id]);
  res.json({ balance: user.balance });
});

// get profile
app.get('/api/me', auth, async (req,res)=>{
  const user = await getAsync('SELECT id,email,balance FROM users WHERE id = ?', [req.user.id]);
  res.json({ user });
});

// --- Matches endpoint (static demo)
const EVENTS = require('./data.json');
app.get('/api/matches', (req,res)=> res.json({ events: EVENTS }));

// --- Betting endpoint (store bet, deduct stake)
app.post('/api/place-bet', auth, async (req,res)=>{
  const { selections, stake } = req.body;
  if(!Array.isArray(selections) || selections.length===0) return res.status(400).json({ error:'no selections' });
  const st = Number(stake) || 0;
  if(st <= 0) return res.status(400).json({ error:'invalid stake' });
  const user = await getAsync('SELECT id,balance FROM users WHERE id = ?', [req.user.id]);
  if(!user) return res.status(400).json({ error:'user not found' });
  if(user.balance < st) return res.status(400).json({ error:'insufficient funds' });
  const totalOdds = selections.reduce((acc,s)=> acc * Number(s.odd), 1);
  const potential = totalOdds * st;
  try{
    await runAsync('BEGIN TRANSACTION;');
    await runAsync('UPDATE users SET balance = balance - ? WHERE id = ?', [st, req.user.id]);
    await runAsync('INSERT INTO bets (user_id, selections, stake, total_odds, potential_return) VALUES (?,?,?,?,?)', [req.user.id, JSON.stringify(selections), st, totalOdds, potential]);
    await runAsync('COMMIT;');
    const updated = await getAsync('SELECT balance FROM users WHERE id = ?', [req.user.id]);
    res.json({ ok:true, balance: updated.balance, potential, totalOdds });
  }catch(e){
    await runAsync('ROLLBACK;');
    console.error(e);
    res.status(500).json({ error:'db' });
  }
});

// list bets
app.get('/api/bets', auth, async (req,res)=>{
  const rows = await allAsync('SELECT id, selections, stake, total_odds, potential_return, status, created_at FROM bets WHERE user_id = ? ORDER BY created_at DESC LIMIT 100', [req.user.id]);
  res.json({ bets: rows.map(r=> ({ ...r, selections: JSON.parse(r.selections) }) ) });
});

// --- Lottery endpoints: buy ticket (auth required), list tickets linked to user, admin draw credits payouts to users
app.post('/api/lottery/buy', auth, async (req,res)=>{
  const { numbers, amount } = req.body;
  if(!Array.isArray(numbers) || numbers.length===0 || !amount) return res.status(400).json({ error:'bad payload' });
  const nums = Array.from(new Set(numbers)).map(n=>Number(n)).filter(n=>n>0).sort((a,b)=>a-b).slice(0,6);
  const ticket_ref = crypto.randomBytes(6).toString('hex');
  // check balance
  const user = await getAsync('SELECT id,balance FROM users WHERE id = ?', [req.user.id]);
  if(!user) return res.status(400).json({ error:'user not found' });
  if(user.balance < amount) return res.status(400).json({ error:'insufficient funds' });
  try{
    await runAsync('BEGIN TRANSACTION;');
    await runAsync('UPDATE users SET balance = balance - ? WHERE id = ?', [amount, req.user.id]);
    await runAsync('INSERT INTO lottery_tickets (ticket_ref, user_id, player_name, numbers, amount) VALUES (?,?,?,?,?)', [ticket_ref, req.user.id, req.user.email, JSON.stringify(nums), amount]);
    await runAsync('COMMIT;');
    const ticket = await getAsync('SELECT id,ticket_ref,player_name,numbers,amount,created_at FROM lottery_tickets WHERE ticket_ref = ?', [ticket_ref]);
    res.json({ ok:true, ticket });
  }catch(e){
    await runAsync('ROLLBACK;');
    console.error(e); res.status(500).json({ error:'db' });
  }
});

app.get('/api/lottery/tickets', auth, async (req,res)=>{
  const rows = await allAsync('SELECT id,ticket_ref,player_name,numbers,amount,drawn,payout,created_at FROM lottery_tickets WHERE user_id = ? ORDER BY created_at DESC LIMIT 200', [req.user.id]);
  res.json({ tickets: rows.map(r=> ({ ...r, numbers: JSON.parse(r.numbers) }) ) });
});

// admin draw - triggers draw, evaluates tickets, credits payouts to users
app.post('/api/lottery/draw', async (req,res)=>{
  const secret = req.query.secret;
  if(!secret || secret !== ADMIN_SECRET) return res.status(403).json({ error:'forbidden' });
  // draw numbers
  const pool = Array.from({length:49}, (_,i)=>i+1);
  const draw = [];
  while(draw.length < 6){
    const idx = Math.floor(Math.random()*pool.length);
    draw.push(pool.splice(idx,1)[0]);
  }
  draw.sort((a,b)=>a-b);
  const drawNumbers = JSON.stringify(draw);
  try{
    await runAsync('BEGIN TRANSACTION;');
    const info = await runAsync('INSERT INTO lottery_draws (draw_numbers) VALUES (?)', [drawNumbers]);
    const drawId = info.lastID;
    const tickets = await allAsync('SELECT id, user_id, numbers, amount FROM lottery_tickets WHERE drawn = 0');
    for(const t of tickets){
      const nums = JSON.parse(t.numbers);
      const matches = nums.filter(n => draw.includes(n)).length;
      let payout = 0;
      if(matches === 6) payout = t.amount * 1000;
      else if(matches === 5) payout = t.amount * 200;
      else if(matches === 4) payout = t.amount * 20;
      else if(matches === 3) payout = t.amount * 5;
      if(payout > 0){
        // credit user's balance
        await runAsync('UPDATE users SET balance = balance + ? WHERE id = ?', [payout, t.user_id]);
      }
      await runAsync('UPDATE lottery_tickets SET drawn = 1, payout = ? WHERE id = ?', [payout, t.id]);
    }
    await runAsync('COMMIT;');
    res.json({ ok:true, draw: { id: drawId, numbers: draw } });
  }catch(e){
    await runAsync('ROLLBACK;');
    console.error(e); res.status(500).json({ error:'db' });
  }
});

app.get('/api/lottery/draws', async (req,res)=>{
  const rows = await allAsync('SELECT id, draw_numbers, draw_at FROM lottery_draws ORDER BY id DESC LIMIT 50');
  res.json({ draws: rows.map(r=> ({ ...r, draw_numbers: JSON.parse(r.draw_numbers) }) ) });
});

// startup
app.listen(PORT, ()=> console.log('BrineBet full-demo server listening on', PORT));
