const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const DB_FILE = process.env.DB_FILE || path.join(__dirname,'brinebet.db');
const INIT_SQL = `
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE,
  password_hash TEXT,
  balance REAL DEFAULT 50,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS bets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  selections TEXT,
  stake REAL,
  total_odds REAL,
  potential_return REAL,
  status TEXT DEFAULT 'SETTLED_DEMO',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS lottery_tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_ref TEXT UNIQUE,
  user_id INTEGER,
  player_name TEXT,
  numbers TEXT,
  amount REAL,
  drawn INTEGER DEFAULT 0,
  payout REAL DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS lottery_draws (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  draw_numbers TEXT,
  draw_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
`;
const db = new sqlite3.Database(DB_FILE);
db.serialize(() => {
  db.exec(INIT_SQL, (err) => {
    if (err) console.error('DB init error', err);
    else console.log('Database initialized at', DB_FILE);
  });
});
module.exports = db;
