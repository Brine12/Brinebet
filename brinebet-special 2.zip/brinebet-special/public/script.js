// Frontend wired to server endpoints for BrineBet full demo.
const SERVER = ''; // server serves static files; same origin

let token = localStorage.getItem('bb_token') || null;
let email = localStorage.getItem('bb_user') || null;

const dom = {
  events: document.getElementById('events'),
  betList: document.getElementById('betList'),
  stake: document.getElementById('stake'),
  totalOdds: document.getElementById('totalOdds'),
  potential: document.getElementById('potential'),
  placeBtn: document.getElementById('placeBtn'),
  balance: document.getElementById('balance'),
  depositBtn: document.getElementById('depositBtn'),
  depositAmount: document.getElementById('depositAmount')
};

let EVENTS = [];
let selections = [];

async function fetchEvents(){
  try {
    const res = await fetch('/api/matches');
    const j = await res.json();
    if(j.events) EVENTS = j.events;
  } catch(e){ console.error('fetch events', e); }
}

function renderEvents(){
  dom.events.innerHTML = '';
  EVENTS.forEach(ev=>{
    const el = document.createElement('div');
    el.className = 'event';
    el.innerHTML = `
      <div>
        <div style="font-weight:700">${ev.teams[0]} <span style="color:#9aa7bf">vs</span> ${ev.teams[1]}</div>
        <div style="color:#9aa7bf;font-size:12px">${ev.league}</div>
      </div>
      <div class="odds"></div>
    `;
    const oddsWrap = el.querySelector('.odds');
    ev.markets.forEach(m=>{
      const b = document.createElement('button');
      b.className = 'odd';
      b.innerText = m.l + '\n' + m.o.toFixed(2);
      b.onclick = () => toggleSelection(ev,m,b);
      oddsWrap.appendChild(b);
    });
    dom.events.appendChild(el);
  });
}

function toggleSelection(ev,m,btn){
  const key = ev.id + '|' + m.k;
  const idx = selections.findIndex(s=>s.key===key);
  if(idx===-1){
    selections.push({ key, matchId: ev.id, teams: ev.teams.join(' vs '), label: m.l, odd: m.o });
    btn.classList.add('selected');
  } else {
    selections.splice(idx,1);
    btn.classList.remove('selected');
  }
  renderBetList();
  recalc();
}

function renderBetList(){
  if(selections.length===0){ dom.betList.innerText = 'No selections'; return; }
  dom.betList.innerHTML = selections.map((s,i)=>`
    <div style="display:flex;justify-content:space-between;padding:6px;border-bottom:1px solid rgba(255,255,255,0.03)">
      ${s.teams} → <strong>${s.label} @ ${s.odd.toFixed(2)}</strong>
      <button data-i="${i}">✕</button>
    </div>
  `).join('');
  dom.betList.querySelectorAll('button').forEach(btn=>btn.onclick=()=>{
    const i = Number(btn.dataset.i);
    selections.splice(i,1);
    document.querySelectorAll('.odd.selected').forEach(el=>el.classList.remove('selected'));
    renderBetList(); recalc();
  });
}

function recalc(){
  if(selections.length===0){ dom.totalOdds.innerText='0'; dom.potential.innerText='0'; return; }
  const totalOdds = selections.reduce((acc,s)=>acc*s.odd,1);
  const stake = Number(dom.stake.value) || 0;
  dom.totalOdds.innerText = totalOdds.toFixed(2);
  dom.potential.innerText = (stake * totalOdds).toFixed(2);
}

// Auth UI (simple modal)
function showAuthModal(mode){
  const html = `
    <div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.5)">
      <div style="background:#071428;padding:16px;border-radius:8px;width:320px">
        <h3>${mode}</h3>
        <label>Email<br/><input id="ma_email" type="email" style="width:100%;padding:8px" /></label>
        <label>Password<br/><input id="ma_pass" type="password" style="width:100%;padding:8px" /></label>
        <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:8px">
          <button id="ma_cancel" class="btn secondary">Cancel</button>
          <button id="ma_submit" class="btn primary">${mode}</button>
        </div>
      </div>
    </div>
  `;
  const wrapper = document.createElement('div');
  wrapper.innerHTML = html;
  document.body.appendChild(wrapper);
  document.getElementById('ma_cancel').onclick = ()=> wrapper.remove();
  document.getElementById('ma_submit').onclick = async ()=>{
    const email = document.getElementById('ma_email').value;
    const pass = document.getElementById('ma_pass').value;
    if(!email || !pass) return alert('Provide email and password');
    try {
      const res = await fetch('/api/' + (mode==='Register'?'register':'login'), {
        method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, password: pass })
      });
      const j = await res.json();
      if(j.token){
        token = j.token; localStorage.setItem('bb_token', token); localStorage.setItem('bb_user', email);
        alert(mode + ' successful');
        wrapper.remove();
        await loadProfile();
      } else {
        alert('Auth failed: ' + (j.error || 'unknown'));
      }
    } catch(e){ alert('Network error'); }
  };
}

// expose sign-in button
const signBtn = document.getElementById('btnSign');
signBtn.onclick = ()=> {
  const mode = confirm('Click OK to Register, Cancel to Login') ? 'Register' : 'Login';
  showAuthModal(mode);
};

async function loadProfile(){
  if(!token){ dom.balance.innerText = 'Sign in'; return; }
  try{
    const res = await fetch('/api/me', { headers: { 'Authorization':'Bearer ' + token }});
    const j = await res.json();
    if(j.user) dom.balance.innerText = j.user.balance.toFixed(2);
  }catch(e){ console.error('profile', e); }
}

// place bet wired to server
dom.placeBtn.onclick = async ()=>{
  if(!token){ alert('Sign in first'); return; }
  if(selections.length===0){ alert('Add selections'); return; }
  const stake = Number(dom.stake.value) || 0;
  if(stake <= 0) return alert('Enter stake');
  try{
    const res = await fetch('/api/place-bet', { method:'POST', headers:{ 'Content-Type':'application/json', 'Authorization':'Bearer '+token }, body: JSON.stringify({ selections, stake })});
    const j = await res.json();
    if(j.ok){ alert('Bet placed (demo). Potential: ' + j.potential.toFixed(2)); selections=[]; document.querySelectorAll('.odd.selected').forEach(e=>e.classList.remove('selected')); renderBetList(); recalc(); loadProfile(); }
    else alert('Place failed: ' + (j.error || 'unknown'));
  }catch(e){ alert('Network error'); }
};

// deposit
dom.depositBtn.onclick = async ()=>{
  if(!token){ alert('Sign in first'); return; }
  const amt = Number(dom.depositAmount.value) || 0;
  if(amt<=0) return alert('Enter amount');
  try{
    const res = await fetch('/api/deposit', { method:'POST', headers:{ 'Content-Type':'application/json', 'Authorization':'Bearer '+token }, body: JSON.stringify({ amount: amt })});
    const j = await res.json();
    if(j.balance !== undefined){ dom.balance.innerText = j.balance.toFixed(2); alert('Deposit added'); }
    else alert('Deposit failed: ' + (j.error || 'unknown'));
  }catch(e){ alert('Network error'); }
};

// Lottery page integration (if present)
if(location.pathname.endsWith('lottery.html')){
  const buyBtn = document.getElementById('buyTicket');
  buyBtn.onclick = async ()=>{
    if(!token){ alert('Sign in to buy tickets'); return; }
    const nums = Array.from(document.querySelectorAll('#numberPicker .odd.selected')).map(b=>Number(b.innerText));
    const amt = Number(document.getElementById('ticketAmount').value) || 1;
    if(nums.length===0) return alert('Pick numbers');
    try{
      const res = await fetch('/api/lottery/buy', { method:'POST', headers:{ 'Content-Type':'application/json','Authorization':'Bearer '+token }, body: JSON.stringify({ numbers: nums, amount: amt })});
      const j = await res.json();
      if(j.ok){ alert('Ticket bought: ' + j.ticket.ticket_ref); loadTickets(); loadProfile(); } else alert('Buy failed: ' + (j.error||'unknown'));
    }catch(e){ alert('Network error'); }
  };
  async function loadTickets(){
    if(!token) return;
    const res = await fetch('/api/lottery/tickets', { headers:{ 'Authorization':'Bearer '+token }});
    const j = await res.json();
    const el = document.getElementById('tickets');
    el.innerHTML = j.tickets.map(t=>`<div style="padding:6px;border-bottom:1px solid rgba(255,255,255,0.03)">${t.created_at} — ${t.numbers.join(', ')} — $${t.amount} — Payout: $${t.payout}</div>`).join('') || '—';
  }
  loadTickets();
}

// init
(async ()=>{
  await fetchEvents();
  renderEvents();
  await loadProfile();
  setInterval(async ()=>{ await fetchEvents(); renderEvents(); }, 15000);
})();
