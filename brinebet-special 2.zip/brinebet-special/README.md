# BrineBet — Full Production-like Demo (what's included & next steps)

This repo is a **demo** that includes many of the core components of a betting site **for development and testing only**:
- Frontend (public/) with betting UI, lottery, and admin draw page.
- Backend (server/) with SQLite, auth (JWT), wallet, bets, and lottery payouts credited to user balances.
- Security middlewares: helmet, CORS, rate-limiting (basic).
- Dockerfile and docker-compose for local container runs.

## What I implemented (development-ready)
- Register/Login (bcrypt + JWT)
- Wallet deposit (demo)
- Place bets (deducts stake)
- Lottery: buy tickets (auth), admin-triggered draw credits payouts to users
- Admin UI to trigger draws
- Server hardening: helmet, CORS, express-rate-limit

## Important: Legal & Compliance (read)
- This is a sandbox. **Do not** use for real-money gambling without obtaining appropriate licenses, integrating compliant payment processors (PCI), KYC/AML, and legal counsel.
- Regulatory obligations differ by jurisdiction. Ensure local compliance before accepting real bets.

## Run locally (development)
1. Install Node.js (v18+).
2. `npm install`
3. `npm start` (creates `server/brinebet.db` on first run)
4. Open http://localhost:4000 — register a user, deposit demo funds, buy tickets, and place bets.
5. Admin draw: visit /admin.html or POST /api/lottery/draw?secret=demo-admin-secret

## Production hardening checklist (next steps you must complete)
- Use secure hosting and HTTPS (TLS).
- Replace SQLite with a production DB (Postgres/MySQL).
- Integrate a licensed payment processor; never store card data unless PCI-compliant.
- Implement full KYC/AML, age verification, geofencing.
- Add logging, monitoring, rate limiting, WAF, DDoS protections.
- Security audit and legal review.
- Terms and responsible gambling tools (limits, self-exclusion, cooling-off).
- Obtain required gambling licenses for target markets.

## Need help?
I can:
- Add CI tests, automated DB migrations, and seed data.
- Implement email verification and password reset via a transactional email provider (SMTP / SendGrid).
- Replace SQLite with Postgres and provide Kubernetes + Docker manifests.
- Integrate a mocked payment flow and expand admin UIs.

This package is a developer-focused demo and intentionally avoids any real-money processing.
