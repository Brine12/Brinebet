# BrineBet Demo

This is a deploy-ready sports betting & lottery demo.

## 🚀 Deploy to Render

1. Create a free account at [https://render.com](https://render.com).
2. Create a new **Web Service**.
3. Connect this repo.
4. Build Command: `npm install`
5. Start Command: `npm start`
6. Deploy 🚀

The site will be live at `https://<your-app-name>.onrender.com`.

