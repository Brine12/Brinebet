
// BrineBet Express Server (GitHub-ready)
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// Rate limiter
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 100 });
app.use(limiter);

// Serve static frontend
app.use(express.static(path.join(__dirname, '../public')));

// Demo endpoints
app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'BrineBet Demo' }));

// Start
app.listen(PORT, () => {
  console.log(`BrineBet server running on port ${PORT}`);
});
